package demo;

import cbhelp.CouchbaseRepository;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import java.util.logging.Logger;

/**
 *
 * @author akshath
 */
public class CouchbaseUtil {
	private static final Logger logger =  Logger.getLogger(CouchbaseUtil.class.getName());
	
	public static final String MAIN_BUCKET = "default";
	
	private static Bucket mainBucket = null;
	
	private static CouchbaseRepository cbr = null;
	
	public static void init(Cluster cluster) {
		logger.info("init");
		
		setMainBucket(cluster.openBucket(MAIN_BUCKET, ""));	//2nd parma is password
	}
	
	public static void close() {
		logger.info("close");
		if(getMainBucket()!=null) {
			getMainBucket().close();
			setMainBucket(null);
		}
	}

	public static Bucket getMainBucket() {
		return mainBucket;
	}

	public static void setMainBucket(Bucket aMainBucket) {
		mainBucket = aMainBucket;
	}
	
	public static CouchbaseRepository getCouchbaseRepository() {
		if(cbr==null) {
			cbr = new CouchbaseRepository(CouchbaseUtil.getMainBucket());
		}
		return cbr;
	}
}
