package demo;


import cbhelp.Entity;
import com.couchbase.client.java.document.JsonDocument;
import com.couchbase.client.java.document.json.JsonObject;
import com.couchbase.client.java.query.N1qlQuery;
import com.couchbase.client.java.query.N1qlQueryResult;
import com.couchbase.client.java.query.N1qlQueryRow;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  
 * 
 * @author akshath
 */
public class Country extends Entity {
	private static final Logger logger =  Logger.getLogger(Country.class.getName());
	
	private String iso2Code;//pk
	private String name;	
	private String iso3Code;
	private String isdCode;
	private int status;
	
	public static List<Country> getEnabledList() {
		List<Country> list = null;
		try {
			//SELECT id, * FROM default WHERE type = 'demo.Country' AND status = 0 ORDER BY name
			Country country = new Country();	
			JsonDocument doc = null;
			
			String statement = "SELECT id, * FROM "+CouchbaseUtil.MAIN_BUCKET+
					" WHERE type = $type AND status = "+
					1+" ORDER BY name";
			logger.log(Level.INFO, "sql: {0}", statement);
			
			JsonObject placeholderValues = JsonObject.create();
			placeholderValues.put("type", country.getType());
			
			logger.log(Level.INFO, "placeholderValues: {0}", placeholderValues);
			
			N1qlQuery query = N1qlQuery.parameterized(statement, placeholderValues);
			N1qlQueryResult result = CouchbaseUtil.getMainBucket().query(query);
			list = new ArrayList<>();
			logger.log(Level.INFO, "result: {0}", result.info());
			logger.log(Level.INFO, "errors: {0}", result.errors());
			
			country = null;
			
			for (N1qlQueryRow row : result)	{		
				logger.log(Level.FINEST, "id: {0}", row.value().getString("id"));
				logger.log(Level.FINEST, "value: {0}", row.value().getObject(CouchbaseUtil.MAIN_BUCKET));
				//doc = JsonDocument.create("country::"+row.value().getString("iso2Code"), row.value().getObject("default"));
				doc = JsonDocument.create(row.value().getString("id"), row.value().getObject(CouchbaseUtil.MAIN_BUCKET));
				country = doc == null ? null : CouchbaseUtil.getCouchbaseRepository().fromJsonDocument(doc, Country.class);
				list.add(country);
			}
			
			return list;
		} catch (Exception e) {
			logger.log(Level.WARNING, "Error: "+e, e);
			return null;
		}
	}
	
	public static void clearDisabled() {
		try {
			Country country = new Country();	
			JsonDocument doc = null;
			
			String statement = "DELETE FROM "+CouchbaseUtil.MAIN_BUCKET+
					" WHERE type = $type AND status = $status";
			logger.log(Level.INFO, "sql: {0}", statement);
			
			JsonObject placeholderValues = JsonObject.create();
			placeholderValues.put("type", country.getType());
			placeholderValues.put("status", 0);
			
			logger.log(Level.FINEST, "placeholderValues: {0}", placeholderValues);
			
			N1qlQuery query = N1qlQuery.parameterized(statement, placeholderValues);
			N1qlQueryResult result = CouchbaseUtil.getMainBucket().query(query);
			
			
			logger.log(Level.INFO, "result: {0}", result.info());
			logger.log(Level.INFO, "errors: {0}", result.errors());			
		} catch (Exception e) {
			logger.log(Level.WARNING, "Error: "+e, e);
			return;
		}
	}

	public String getIso2Code() {
		return iso2Code;
	}

	public void setIso2Code(String iso2Code) {
		this.iso2Code = iso2Code;
		setId("Country::"+iso2Code);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIso3Code() {
		return iso3Code;
	}

	public void setIso3Code(String iso3Code) {
		this.iso3Code = iso3Code;
	}

	public String getIsdCode() {
		return isdCode;
	}

	public void setIsdCode(String isdCode) {
		this.isdCode = isdCode;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
