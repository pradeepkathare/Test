package demo;


import cbhelp.CouchbaseRepository;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.query.Index;
import com.couchbase.client.java.query.N1qlQuery;
import static com.couchbase.client.java.query.dsl.Expression.x;
import com.couchbase.client.java.query.dsl.path.index.IndexType;
import java.util.List;

/*

 *
 * @author akshath, @date 7/3/17 11:23 PM
 */
public class HelloCouchbase {
	
	public static String seedNodes = "172.104.45.23";
	
		
    public static void main(String args[]) {
        System.out.println("Hello");		
		
		Cluster cluster = CouchbaseCluster.create(seedNodes);		
		CouchbaseUtil.init(cluster);
		CouchbaseRepository cbr = CouchbaseUtil.getCouchbaseRepository();
		
		//setup(cbr);
		
		List<Country> list = Country.getEnabledList();
		System.out.println("EnabledList... "+list.size());
		for(int i=0;i<list.size();i++) {
			System.out.println(""+i+": "+list.get(i));			
		}
		System.out.println("End");
                
		
		Country.clearDisabled();
	}
	
	private static void setup(CouchbaseRepository cbr) {
		System.out.println("Setup...");
		
		Country country = new Country();
		country.setIso2Code("IN");
		country.setIso3Code("IND");
		country.setName("India");
		country.setIsdCode("91");
		country.setStatus(1);			
		
		//country = cbr.create(country, Country.class);		
		country = cbr.upsert(country, Country.class);
		
		country = new Country();
		country.setIso2Code("US");
		country.setIso3Code("USA");
		country.setName("USA");
		country.setIsdCode("1");
		country.setStatus(0);			
		
		//country = cbr.create(country, Country.class);		
		country = cbr.upsert(country, Country.class);
		
		if(true) {
			//CREATE INDEX idx_type_id on default (type, id);
			CouchbaseUtil.getMainBucket().query(N1qlQuery.simple(Index.createIndex("idx_type_id")
				.on(CouchbaseUtil.MAIN_BUCKET, x("type"), x("id"))
				.using(IndexType.GSI)));

			//CREATE INDEX idx_type_status on default (type, status);
			CouchbaseUtil.getMainBucket().query(N1qlQuery.simple(Index.createIndex("idx_type_status")
				.on(CouchbaseUtil.MAIN_BUCKET, x("type"), x("status"))
				.where(x("status").isNotMissing())
				.using(IndexType.GSI)));
			
			CouchbaseUtil.getMainBucket().query(N1qlQuery.simple(Index.createIndex("idx_type_isd_phone")
				.on(CouchbaseUtil.MAIN_BUCKET, x("type"), x("isdCode"), x("phone"))
				.where(x("isdCode").isNotMissing()
					.and("phone").isNotMissing())
				.using(IndexType.GSI)));
		}		
    }
}
